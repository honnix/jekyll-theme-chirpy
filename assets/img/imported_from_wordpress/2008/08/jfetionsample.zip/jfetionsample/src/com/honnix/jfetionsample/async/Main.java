/**
 * Main.java
 * 
 * Copyright : (C) 2008 by Honnix
 * Email     : hxliang1982@gmail.com
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 * 
 */
package com.honnix.jfetionsample.async;

import com.honnix.jfetion.FetionMessageControl;
import com.honnix.jfetion.FetionSessionControl;
import com.honnix.jfetion.impl.FetionFactory;
import com.honnix.jfetionsample.async.event.LoginEventListener;
import com.honnix.jfetionsample.async.event.SmsEventListener;

/**
 *
 */
public class Main
{

    private static Checker checker = new Checker();

    private static LoginEventListener loginEventListener = new LoginEventListener();

    private static SmsEventListener smsEventListener = new SmsEventListener();

    /**
     * @param args
     */
    public static void main(String[] args)
    {
        FetionSessionControl fetionSession = FetionFactory
                .getFetionSessionControl();
        FetionMessageControl fetionMessage = FetionFactory
                .getFetionMessageControl();

        fetionSession.init();

        checker.setCalled(false);
        fetionSession.asyncLogin("13800138000", "13800138000",
                loginEventListener, checker);
        waitUntilCalledBack();

        checker.setCalled(false);
        fetionMessage.asyncSendSmsToSelf("Send SMS to myself.",
                smsEventListener, checker);
        waitUntilCalledBack();

        fetionSession.logout();
        fetionSession.terminate();
    }

    private static void waitUntilCalledBack()
    {
        while (true)
        {
            if (checker.isCalled())
            {
                break;
            }

            try
            {
                Thread.sleep(100);
            }
            catch (InterruptedException e)
            {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
    }

}
